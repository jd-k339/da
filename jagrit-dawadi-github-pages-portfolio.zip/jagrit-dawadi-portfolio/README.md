# Jagrit Dawadi — Student Portfolio

A simple one-file portfolio website designed for GitHub Pages.

## Four GitHub Pages

This project is intentionally a **single HTML file**. The four sections/pages are:

1. Home
2. About / Education
3. Projects / Skills
4. Contact

The navigation jumps to each page section while keeping the project as one file.

## Publish on GitHub Pages

1. Create a new GitHub repository.
2. Upload `index.html`.
3. Go to **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select your main branch and `/ (root)`.
6. Save and wait for GitHub Pages to publish.

## Personalize

Search `index.html` for:
- `your.email@example.com`
- `yourusername`
- `Add your university name`
- `Previous Education`
- Project descriptions
- LinkedIn link

You can also replace the `JD` circle with a photo later if desired.
